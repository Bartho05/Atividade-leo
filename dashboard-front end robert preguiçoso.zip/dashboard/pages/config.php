<?php
require_once '../includes/config.php';

if (!estaLogado()) {
    header('Location: ../index.php');
    exit;
}

require_once '../includes/header.php';
$p = perfil();
?>

<h1>Configurações</h1>
<div class="subtitulo">Preferências do sistema</div>

<?php if ($p === 'admin'): ?>

  <div class="bloco">
    <h2>Configurações gerais</h2>
    <table class="tabela">
      <tr><td><strong>Nome do sistema</strong></td><td>Meu Sistema</td></tr>
      <tr><td><strong>Versão</strong></td><td>1.0.0</td></tr>
      <tr><td><strong>Manutenção</strong></td><td><span class="tag tag-verde">Desativada</span></td></tr>
      <tr><td><strong>Modo debug</strong></td><td><span class="tag tag-amarela">Ativo</span></td></tr>
    </table>
  </div>

  <div class="bloco">
    <h2>Permissões de perfis</h2>
    <table class="tabela">
      <tr><th>Perfil</th><th>Acesso admin</th><th>Acesso relatórios</th><th>Acesso config</th></tr>
      <tr><td>Administrador</td><td><span class="tag tag-verde">Sim</span></td><td><span class="tag tag-verde">Sim</span></td><td><span class="tag tag-verde">Sim</span></td></tr>
      <tr><td>Gestor</td><td><span class="tag tag-vermelho">Não</span></td><td><span class="tag tag-verde">Sim</span></td><td><span class="tag tag-vermelho">Não</span></td></tr>
      <tr><td>Usuário</td><td><span class="tag tag-vermelho">Não</span></td><td><span class="tag tag-vermelho">Não</span></td><td><span class="tag tag-vermelho">Não</span></td></tr>
    </table>
  </div>

<?php else: ?>

  <div class="bloco">
    <h2>Preferências da conta</h2>
    <table class="tabela">
      <tr><td><strong>Notificações por e-mail</strong></td><td><span class="tag tag-verde">Ativadas</span></td></tr>
      <tr><td><strong>Idioma</strong></td><td>Português (Brasil)</td></tr>
      <tr><td><strong>Fuso horário</strong></td><td>America/Sao_Paulo</td></tr>
    </table>
  </div>

<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
