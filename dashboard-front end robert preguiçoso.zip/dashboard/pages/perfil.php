<?php
require_once '../includes/config.php';

if (!estaLogado()) {
    header('Location: ../index.php');
    exit;
}

// Ajustar caminho do CSS para subpasta
$cssPath = '../assets/style.css';
$u = usuario();
$p = perfil();

require_once '../includes/header.php';
?>

<h1>Meu Perfil</h1>
<div class="subtitulo">Informações da sua conta</div>

<div class="bloco">
  <h2>Dados pessoais</h2>
  <table class="tabela">
    <tr><td><strong>Nome</strong></td><td><?= htmlspecialchars($u['nome']) ?></td></tr>
    <tr><td><strong>Login</strong></td><td><?= htmlspecialchars($u['login']) ?></td></tr>
    <tr><td><strong>Perfil</strong></td><td><?= nomePerfil() ?></td></tr>
  </table>
</div>

<?php require_once '../includes/footer.php'; ?>
