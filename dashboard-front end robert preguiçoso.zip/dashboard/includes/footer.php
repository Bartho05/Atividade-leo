<?php
// includes/footer.php
?>
  </div><!-- /conteudo -->
</div><!-- /pagina -->

<div class="rodape">
  &copy; <?= date('Y') ?> Meu Sistema &mdash; Todos os direitos reservados.
</div>

</body>
</html>
