<?php
require_once '../includes/config.php';
require_once '../includes/header.php';
?>

<h1>Sobre o Sistema</h1>
<div class="subtitulo">Informações gerais</div>

<div class="bloco">
  <h2>O que é este sistema?</h2>
  <p style="font-size:14px; line-height:1.7; color:#555;">
    Este é um sistema de dashboard desenvolvido em PHP puro com CSS personalizado.
    Ele oferece painéis diferenciados por tipo de usuário: administrador, gestor e usuário comum.
    Acesse com login para ver o painel completo.
  </p>
</div>

<div class="bloco">
  <h2>Tecnologias utilizadas</h2>
  <table class="tabela">
    <tr><th>Tecnologia</th><th>Uso</th></tr>
    <tr><td>PHP 8+</td><td>Backend e lógica de autenticação</td></tr>
    <tr><td>CSS3</td><td>Estilização e layout responsivo</td></tr>
    <tr><td>Sessões PHP</td><td>Controle de login e perfis</td></tr>
  </table>
</div>

<?php require_once '../includes/footer.php'; ?>
