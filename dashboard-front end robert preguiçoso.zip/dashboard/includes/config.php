<?php
session_start();

// Usuários disponíveis (em produção, substitua por banco de dados)
$usuarios = [
    'admin'  => ['senha' => '123', 'nome' => 'Administrador', 'perfil' => 'admin'],
    'joao'   => ['senha' => '123', 'nome' => 'João Silva',    'perfil' => 'usuario'],
    'carlos' => ['senha' => '123', 'nome' => 'Carlos Gestor', 'perfil' => 'gestor'],
];

// Processar login / logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    if ($_POST['acao'] === 'login') {
        $login = trim($_POST['usuario'] ?? '');
        $senha = trim($_POST['senha']   ?? '');
        if (isset($usuarios[$login]) && $usuarios[$login]['senha'] === $senha) {
            $_SESSION['usuario']          = $usuarios[$login];
            $_SESSION['usuario']['login'] = $login;
            unset($_SESSION['erro_login']);
        } else {
            $_SESSION['erro_login'] = 'Usuário ou senha inválidos.';
        }
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }
    if ($_POST['acao'] === 'logout') {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}

// Funções auxiliares
function estaLogado(): bool {
    return isset($_SESSION['usuario']);
}

function usuario(): ?array {
    return $_SESSION['usuario'] ?? null;
}

function perfil(): string {
    return $_SESSION['usuario']['perfil'] ?? '';
}

function nomePerfil(): string {
    return match(perfil()) {
        'admin'  => 'Administrador',
        'gestor' => 'Gestor',
        default  => 'Usuário',
    };
}
