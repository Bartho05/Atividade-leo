<?php
require_once '../includes/config.php';
require_once '../includes/header.php';
?>

<h1>Contato</h1>
<div class="subtitulo">Fale conosco</div>

<div class="bloco">
  <h2>Informações de contato</h2>
  <table class="tabela">
    <tr><td><strong>E-mail</strong></td><td>contato@meusistema.com.br</td></tr>
    <tr><td><strong>Telefone</strong></td><td>(11) 99999-0000</td></tr>
    <tr><td><strong>Horário de atendimento</strong></td><td>Segunda a sexta, das 8h às 18h</td></tr>
  </table>
</div>

<?php require_once '../includes/footer.php'; ?>
