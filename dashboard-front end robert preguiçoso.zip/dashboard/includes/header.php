<?php
// includes/header.php
$u = usuario();
$p = perfil();

// Detecta se está em subpasta para ajustar o caminho do CSS
$emSubpasta = strpos(dirname($_SERVER['PHP_SELF']), '/pages') !== false;
$basePath   = $emSubpasta ? '../' : '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link rel="stylesheet" href="<?= $basePath ?>assets/style.css">
</head>
<body>

<!-- ══ TOPO ══ -->
<div class="topo">
  <div class="titulo">Meu Sistema</div>

  <?php if (!estaLogado()): ?>
    <!-- Não logado: formulário de login no topo -->
    <form class="form-login" method="POST" action="<?= $basePath ?>index.php">
      <input type="hidden" name="acao" value="login">
      <input type="text"     name="usuario" placeholder="Usuário">
      <input type="password" name="senha"   placeholder="Senha">
      <button type="submit">Entrar</button>
    </form>

  <?php else: ?>
    <!-- Logado: saudação + perfil + links -->
    <div class="usuario-info">
      <div class="saudacao">
        Olá, <span><?= htmlspecialchars($u['nome']) ?></span>
        <span class="badge-perfil badge-<?= $p ?>"><?= nomePerfil() ?></span>
      </div>
      <div class="links">
        <a href="<?= $basePath ?>pages/perfil.php">Perfil</a>
        <a href="<?= $basePath ?>pages/config.php">Configurações</a>
        <form method="POST" action="<?= $basePath ?>index.php" style="display:inline">
          <input type="hidden" name="acao" value="logout">
          <button type="submit">Sair</button>
        </form>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php if (!empty($_SESSION['erro_login'])): ?>
  <div class="erro"><?= htmlspecialchars($_SESSION['erro_login']) ?></div>
  <?php unset($_SESSION['erro_login']); ?>
<?php endif; ?>

<!-- ══ LAYOUT: lateral + conteúdo ══ -->
<div class="pagina">

  <!-- ── MENU LATERAL ── -->
  <?php include __DIR__ . '/sidebar.php'; ?>

  <!-- ── CONTEÚDO ── -->
  <div class="conteudo">
