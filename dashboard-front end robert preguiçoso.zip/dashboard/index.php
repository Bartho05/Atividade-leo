<?php
require_once 'includes/config.php';
require_once 'includes/header.php';

$u = usuario();
$p = perfil();
?>

<?php if (!estaLogado()): ?>

  <!-- ══ VISITANTE ══ -->
  <div class="bem-vindo">
    <h2>Bem-vindo ao Sistema</h2>
    <p>Esta é uma página pública. Faça login para acessar o painel completo.</p>
    <p>Você pode navegar pelo conteúdo geral, mas recursos avançados exigem autenticação.</p>
    <div class="dica">
      Credenciais de teste: &nbsp;
      <strong>admin</strong> / 123 &nbsp;&middot;&nbsp;
      <strong>joao</strong> / 123 &nbsp;&middot;&nbsp;
      <strong>carlos</strong> / 123
    </div>
  </div>

<?php elseif ($p === 'admin'): ?>

  <!-- ══ ADMIN ══ -->
  <h1>Painel Administrativo</h1>
  <div class="subtitulo">Visão geral do sistema</div>

  <div class="cards">
    <div class="card azul">
      <div class="rotulo">Total de usuários</div>
      <div class="valor">1.284</div>
    </div>
    <div class="card verde">
      <div class="rotulo">Receita mensal</div>
      <div class="valor">R$ 48k</div>
    </div>
    <div class="card laranja">
      <div class="rotulo">Pendências</div>
      <div class="valor">37</div>
    </div>
    <div class="card vermelho">
      <div class="rotulo">Erros no sistema</div>
      <div class="valor">2</div>
    </div>
  </div>

  <div class="bloco">
    <h2>Usuários cadastrados</h2>
    <table class="tabela">
      <tr><th>Nome</th><th>Perfil</th><th>Status</th></tr>
      <tr><td>João Silva</td><td>Usuário</td><td><span class="tag tag-verde">Ativo</span></td></tr>
      <tr><td>Carlos Gestor</td><td>Gestor</td><td><span class="tag tag-verde">Ativo</span></td></tr>
      <tr><td>Maria Souza</td><td>Usuário</td><td><span class="tag tag-amarela">Pendente</span></td></tr>
      <tr><td>Pedro Lima</td><td>Usuário</td><td><span class="tag tag-azul">Inativo</span></td></tr>
    </table>
  </div>

  <div class="bloco">
    <h2>Últimas ações no sistema</h2>
    <table class="tabela">
      <tr><th>Ação</th><th>Usuário</th><th>Data</th></tr>
      <tr><td>Login realizado</td><td>joao</td><td>10/06/2026 09:14</td></tr>
      <tr><td>Pedido criado</td><td>maria</td><td>10/06/2026 08:55</td></tr>
      <tr><td>Configuração alterada</td><td>admin</td><td>09/06/2026 17:30</td></tr>
    </table>
  </div>

<?php elseif ($p === 'gestor'): ?>

  <!-- ══ GESTOR ══ -->
  <h1>Painel do Gestor</h1>
  <div class="subtitulo">Olá, <?= htmlspecialchars($u['nome']) ?>! Aqui está o resumo da sua equipe.</div>

  <div class="cards">
    <div class="card azul">
      <div class="rotulo">Membros na equipe</div>
      <div class="valor">8</div>
    </div>
    <div class="card verde">
      <div class="rotulo">Tarefas concluídas</div>
      <div class="valor">54</div>
    </div>
    <div class="card laranja">
      <div class="rotulo">Em andamento</div>
      <div class="valor">12</div>
    </div>
  </div>

  <div class="bloco">
    <h2>Tarefas da equipe</h2>
    <table class="tabela">
      <tr><th>Tarefa</th><th>Responsável</th><th>Prazo</th><th>Status</th></tr>
      <tr><td>Relatório mensal</td><td>Ana Paula</td><td>12/06</td><td><span class="tag tag-amarela">Em andamento</span></td></tr>
      <tr><td>Revisão de contratos</td><td>Bruno Costa</td><td>14/06</td><td><span class="tag tag-azul">Não iniciado</span></td></tr>
      <tr><td>Apresentação de resultados</td><td>Carlos Gestor</td><td>15/06</td><td><span class="tag tag-verde">Concluído</span></td></tr>
    </table>
  </div>

  <div class="bloco">
    <h2>Minha equipe</h2>
    <table class="tabela">
      <tr><th>Nome</th><th>Cargo</th><th>Status</th></tr>
      <tr><td>Ana Paula</td><td>Analista</td><td><span class="tag tag-verde">Ativo</span></td></tr>
      <tr><td>Bruno Costa</td><td>Desenvolvedor</td><td><span class="tag tag-verde">Ativo</span></td></tr>
      <tr><td>Letícia Melo</td><td>Designer</td><td><span class="tag tag-amarela">Férias</span></td></tr>
    </table>
  </div>

<?php else: ?>

  <!-- ══ USUÁRIO COMUM ══ -->
  <h1>Olá, <?= htmlspecialchars($u['nome']) ?>!</h1>
  <div class="subtitulo">Aqui estão seus dados e pedidos recentes.</div>

  <div class="cards">
    <div class="card azul">
      <div class="rotulo">Meus pedidos</div>
      <div class="valor">12</div>
    </div>
    <div class="card laranja">
      <div class="rotulo">Pendentes</div>
      <div class="valor">3</div>
    </div>
    <div class="card verde">
      <div class="rotulo">Concluídos</div>
      <div class="valor">9</div>
    </div>
  </div>

  <div class="bloco">
    <h2>Meus pedidos recentes</h2>
    <table class="tabela">
      <tr><th>Pedido</th><th>Descrição</th><th>Data</th><th>Status</th></tr>
      <tr><td>#1042</td><td>Produto A</td><td>10/06/2026</td><td><span class="tag tag-verde">Entregue</span></td></tr>
      <tr><td>#1039</td><td>Produto B</td><td>08/06/2026</td><td><span class="tag tag-amarela">Em trânsito</span></td></tr>
      <tr><td>#1031</td><td>Produto C</td><td>01/06/2026</td><td><span class="tag tag-verde">Entregue</span></td></tr>
    </table>
  </div>

  <div class="bloco">
    <h2>Meus dados</h2>
    <table class="tabela">
      <tr><td><strong>Nome</strong></td><td><?= htmlspecialchars($u['nome']) ?></td></tr>
      <tr><td><strong>Login</strong></td><td><?= htmlspecialchars($u['login']) ?></td></tr>
      <tr><td><strong>Perfil</strong></td><td>Usuário comum</td></tr>
    </table>
  </div>

<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
