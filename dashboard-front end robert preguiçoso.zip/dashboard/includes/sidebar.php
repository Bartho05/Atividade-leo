<?php
// includes/sidebar.php
$p          = perfil();
$emSubpasta = strpos(dirname($_SERVER['PHP_SELF']), '/pages') !== false;
$base       = $emSubpasta ? '../' : '';
$pagesBase  = $emSubpasta ? '' : 'pages/';
$paginaAtual = basename($_SERVER['PHP_SELF']);

function ativo(string $arquivo): string {
    return basename($_SERVER['PHP_SELF']) === $arquivo ? ' class="ativo"' : '';
}
?>
<div class="lateral">

  <?php if (!estaLogado()): ?>
    <div class="titulo-menu">Navegação</div>
    <a href="<?= $base ?>index.php"<?= ativo('index.php') ?>>Início</a>
    <a href="<?= $base ?>pages/sobre.php"<?= ativo('sobre.php') ?>>Sobre</a>
    <a href="<?= $base ?>pages/contato.php"<?= ativo('contato.php') ?>>Contato</a>

  <?php elseif ($p === 'admin'): ?>
    <div class="titulo-menu">Administração</div>
    <a href="<?= $base ?>index.php"<?= ativo('index.php') ?>>Dashboard</a>
    <a href="<?= $base ?>pages/usuarios.php"<?= ativo('usuarios.php') ?>>Usuários</a>
    <a href="<?= $base ?>pages/relatorios.php"<?= ativo('relatorios.php') ?>>Relatórios</a>
    <hr class="separador">
    <div class="titulo-menu">Sistema</div>
    <a href="<?= $base ?>pages/config.php"<?= ativo('config.php') ?>>Configurações</a>
    <a href="<?= $base ?>pages/perfil.php"<?= ativo('perfil.php') ?>>Meu perfil</a>

  <?php elseif ($p === 'gestor'): ?>
    <div class="titulo-menu">Gestão</div>
    <a href="<?= $base ?>index.php"<?= ativo('index.php') ?>>Painel</a>
    <a href="<?= $base ?>pages/relatorios.php"<?= ativo('relatorios.php') ?>>Relatórios</a>
    <hr class="separador">
    <div class="titulo-menu">Conta</div>
    <a href="<?= $base ?>pages/perfil.php"<?= ativo('perfil.php') ?>>Meu perfil</a>
    <a href="<?= $base ?>pages/config.php"<?= ativo('config.php') ?>>Configurações</a>

  <?php else: ?>
    <div class="titulo-menu">Meu painel</div>
    <a href="<?= $base ?>index.php"<?= ativo('index.php') ?>>Início</a>
    <hr class="separador">
    <div class="titulo-menu">Conta</div>
    <a href="<?= $base ?>pages/perfil.php"<?= ativo('perfil.php') ?>>Meu perfil</a>
    <a href="<?= $base ?>pages/config.php"<?= ativo('config.php') ?>>Configurações</a>

  <?php endif; ?>

</div>
